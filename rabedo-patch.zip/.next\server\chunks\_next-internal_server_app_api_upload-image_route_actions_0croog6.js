module.exports=[60754,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-image_route_actions_0croog6.js.map