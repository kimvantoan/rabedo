module.exports=[34895,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_public_articles_route_actions_125obs2.js.map