var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/articles/route.js")
R.c("server/chunks/[root-of-the-server]__0r_xgne._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__0bp.ded._.js")
R.c("server/chunks/_next-internal_server_app_api_articles_route_actions_13wx-a_.js")
R.m(91693)
module.exports=R.m(91693).exports
