var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload-image/route.js")
R.c("server/chunks/[root-of-the-server]__0up9o8m._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__0bp.ded._.js")
R.c("server/chunks/_next-internal_server_app_api_upload-image_route_actions_0croog6.js")
R.m(48344)
module.exports=R.m(48344).exports
