module.exports=[82799,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_public_articles_%5Bslug%5D_route_actions_0n4vpez.js.map