var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate-article/route.js")
R.c("server/chunks/[root-of-the-server]__0fq2vl0._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_generate-article_route_actions_0fo7coc.js")
R.m(91164)
module.exports=R.m(91164).exports
