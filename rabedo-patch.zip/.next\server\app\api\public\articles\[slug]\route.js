var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/articles/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__0ypif~w._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_public_articles_[slug]_route_actions_0n4vpez.js")
R.m(42156)
module.exports=R.m(42156).exports
