var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/articles/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0_b.e6.._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__0bp.ded._.js")
R.c("server/chunks/_next-internal_server_app_api_articles_[id]_route_actions_10e70w5.js")
R.m(31584)
module.exports=R.m(31584).exports
