globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/FmghOV1xxGoaIKP-KekMQ/_buildManifest.js",
    "static/FmghOV1xxGoaIKP-KekMQ/_ssgManifest.js",
    "static/FmghOV1xxGoaIKP-KekMQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0yp8owlnu5ns~.js",
    "static/chunks/0mstyq17cbf8-.js",
    "static/chunks/0f~5-~0.aya7z.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-15y_m68f8bvtf.js"
  ]
};
