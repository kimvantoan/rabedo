var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/login/route.js")
R.c("server/chunks/[root-of-the-server]__06c5ug9._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0pwd2_f.js")
R.c("server/chunks/[root-of-the-server]__0bp.ded._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_login_route_actions_0rrez75.js")
R.m(25586)
module.exports=R.m(25586).exports
