var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/articles/route.js")
R.c("server/chunks/[root-of-the-server]__0j~ak2v._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_public_articles_route_actions_125obs2.js")
R.m(22770)
module.exports=R.m(22770).exports
