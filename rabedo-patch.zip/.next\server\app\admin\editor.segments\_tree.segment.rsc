:HL["/_next/static/chunks/0tth_hoqwkxtx.css","style"]
:HL["/_next/static/media/2bbe8d2671613f1f-s.p.067x_6k0k23tk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/70bc3e132a0a741e-s.p.1409xf.ylxg8g.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.0q-301v4kxxnr.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/89b21bb081cb7469-s.p.0gfhww.tctz1o.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/chunks/0o2hqcqqaj~cm.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"admin","param":null,"prefetchHints":0,"slots":{"children":{"name":"editor","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"FmghOV1xxGoaIKP-KekMQ"}
