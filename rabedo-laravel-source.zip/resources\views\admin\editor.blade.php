@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
    <div class="mb-8 flex items-center justify-between">
        <h1 class="text-3xl font-bold tracking-tight text-gray-900">Viết bài mới</h1>
        <a href="{{ route('admin.dashboard') }}" class="text-sm font-medium text-gray-500 hover:text-gray-900">Quay lại Dashboard</a>
    </div>

    <form action="{{ route('admin.store') }}" method="POST" class="space-y-6 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
        @csrf

        <!-- Error Alert -->
        @if ($errors->any())
            <div class="rounded-md bg-red-50 p-4 border border-red-200">
                <div class="flex">
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-red-800">Có lỗi xảy ra:</h3>
                        <div class="mt-2 text-sm text-red-700">
                            <ul class="list-disc space-y-1 pl-5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <div>
            <label for="title" class="block text-sm font-medium text-gray-700">Tiêu đề bài viết</label>
            <div class="mt-1">
                <input type="text" name="title" id="title" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-3 border placeholder-gray-400" placeholder="Nhập tiêu đề..." value="{{ old('title') }}" required>
            </div>
        </div>

        <div>
            <label for="type" class="block text-sm font-medium text-gray-700">Phân loại (Type)</label>
            <div class="mt-1">
                <select id="type" name="type" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-3 border">
                    <option value="Admin">Admin</option>
                    <option value="News">Tin Tức</option>
                    <option value="Blog">Blog</option>
                </select>
            </div>
        </div>

        <div>
            <label for="content" class="block text-sm font-medium text-gray-700">Nội dung HTML</label>
            <div class="mt-1">
                <textarea id="content" name="content" rows="15" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-3 border font-mono" required>{{ old('content') }}</textarea>
            </div>
            <p class="mt-2 text-sm text-gray-500">Hỗ trợ viết mã HTML trực tiếp.</p>
        </div>

        <div class="pt-5 border-t">
            <div class="flex justify-end">
                <button type="button" class="rounded-md border border-gray-300 bg-white py-2 px-4 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">Hủy</button>
                <button type="submit" class="ml-3 inline-flex justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">Lưu bài viết</button>
            </div>
        </div>
    </form>
</div>
@endsection
