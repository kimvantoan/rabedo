<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tin Tức & Blog</title>
    <!-- Tailwind CSS CDN (Không cần build NPM trên cPanel) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              blue: {
                600: '#2563eb',
              }
            }
          }
        }
      }
    </script>
</head>
<body class="min-h-full flex flex-col antialiased bg-white text-black">
    <header class="border-b bg-white relative top-0 z-50">
        <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <a href="{{ route('home') }}" class="font-bold text-xl tracking-tight text-blue-600">Rabedo</a>
            <nav class="hidden sm:flex space-x-6">
                <a href="{{ route('home') }}" class="text-gray-600 hover:text-black">Trang chủ</a>
            </nav>
            <div class="flex items-center space-x-4">
                @auth
                    <a href="{{ route('admin.dashboard') }}" class="text-sm font-medium text-gray-700 hover:text-black">Đến Dashboard</a>
                    <form method="POST" action="{{ route('logout') }}" class="inline">
                        @csrf
                        <button type="submit" class="text-sm font-medium text-red-600 hover:text-red-800">Đăng xuất</button>
                    </form>
                @else
                    <a href="{{ route('login') }}" class="text-sm font-medium text-gray-700 hover:text-black">Đăng nhập Admin</a>
                @endauth
            </div>
        </div>
    </header>

    <main class="flex-grow">
        @yield('content')
    </main>

    <footer class="bg-gray-50 border-t mt-auto">
        <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 text-center text-sm text-gray-500">
            &copy; {{ date('Y') }} Rabedo. All rights reserved.
        </div>
    </footer>
</body>
</html>
