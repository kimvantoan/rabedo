<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    // Apply basic auth middleware if needed
    // public function __construct() { $this->middleware('auth'); }

    public function index()
    {
        $articles = Article::orderBy('created_at', 'desc')->paginate(15);
        return view('admin.dashboard', compact('articles'));
    }

    public function editor()
    {
        return view('admin.editor');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'type' => 'required|string',
        ]);

        $article = new Article;
        $article->title = $validated['title'];
        // Generate a random slug fallback, or create proper slug function
        $article->slug = \Illuminate\Support\Str::slug($validated['title']) . '-' . time();
        $article->content = $validated['content'];
        $article->type = $validated['type'];
        $article->author = auth()->user() ? auth()->user()->name : 'Admin';
        $article->created_at = now();
        $article->updated_at = now();
        $article->save();

        return redirect()->route('admin.dashboard')->with('success', 'Article saved successfully.');
    }
}
