@extends('layouts.app')

@section('content')
<div class="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8 bg-white my-8 rounded-2xl shadow-sm ring-1 ring-gray-100">
    <div class="text-sm text-gray-500 mb-6 flex items-center gap-4">
        <a href="{{ route('home') }}" class="hover:text-black hover:underline flex items-center gap-1">
            <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
            Quay lại
        </a>
        <span>|</span>
        <time datetime="{{ $article->created_at }}">{{ \Carbon\Carbon::parse($article->created_at)->format('d/m/Y H:i') }}</time>
        <span class="bg-gray-100 px-2 py-1 rounded-md">{{ $article->type }}</span>
    </div>
    <h1 class="text-4xl font-bold tracking-tight text-gray-900 mb-8">{{ $article->title }}</h1>
    
    @if($article->thumbnail)
        <div class="w-full aspect-video rounded-xl overflow-hidden mb-10 bg-gray-100">
            <img src="{{ $article->thumbnail }}" alt="{{ $article->title }}" class="object-cover w-full h-full">
        </div>
    @endif

    <div class="prose prose-blue prose-lg max-w-none text-gray-700">
        {!! $article->content !!}
    </div>
    
    @if($article->author)
        <div class="mt-12 pt-8 border-t flex items-center gap-4">
            <div class="bg-blue-100 text-blue-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">
                {{ substr($article->author, 0, 1) }}
            </div>
            <div>
                <p class="text-sm font-semibold text-gray-900">Tác giả</p>
                <p class="text-base text-gray-600">{{ $article->author }}</p>
            </div>
        </div>
    @endif
</div>
@endsection
